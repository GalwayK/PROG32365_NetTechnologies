﻿/*
 * Assignment: 1
 * Name: Kyle Galway
 * ID: 991418738
 * This is the interface for dictating whether an instrument is fixable.
*/
namespace MusicShop
{
    internal interface IFixable
    {
        public abstract string HowToFix();
    }
}
