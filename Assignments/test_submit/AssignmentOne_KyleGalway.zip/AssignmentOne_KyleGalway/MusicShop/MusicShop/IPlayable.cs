﻿/*
 * Assignment: 1
 * Name: Kyle Galway
 * ID: 991418738
 * This is the interface for dictating whether an instrument is playable.
*/
namespace MusicShop
{
    internal interface IPlayable
    {
        public abstract string HowToPlay();
    }
}
